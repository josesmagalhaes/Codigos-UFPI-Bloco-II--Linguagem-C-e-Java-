
package trabalhofinal;

public class Instrutor extends Pessoa implements Carteira{
    private Carteira codigo;
    
    public Instrutor(String nome, int idade) {
        super(nome, idade);
    }

    public Carteira getCodigo() {
        return codigo;
    }

    public void setCodigo(Carteira codigo) {
        this.codigo = codigo;
    }

    @Override
    public String toString() {
        return "Instrutor: " + super.toString()+"Codigo da Carteira: " + codigoconfef + '.';
    }
    
    
    
}

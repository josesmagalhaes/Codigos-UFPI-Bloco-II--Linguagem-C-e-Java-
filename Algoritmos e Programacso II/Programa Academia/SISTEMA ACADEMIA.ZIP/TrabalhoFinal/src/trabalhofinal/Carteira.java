
package trabalhofinal;

public interface Carteira {
    String codigoconfef = "2017-1005-0001/RH";
    
}

package trabalhofinal;


public class Mulher extends Cliente{
    
    public Mulher(String nome, int idade, Equipamento equipamento) {
        super(nome, idade, equipamento);
    }
    
}

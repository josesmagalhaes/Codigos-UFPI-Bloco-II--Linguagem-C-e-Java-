
package trabalhofinal;


public class Homem extends Cliente{
    
    public Homem(String nome, int idade, Equipamento equipamento) {
        super(nome, idade, equipamento);
    }
    
}
